package ru.korpse.testapp

import java.net.URI
import org.jboss.netty.util.CharsetUtil

object Main {
  def main(args: Array[String]): Unit = {
    var client = WebSocketClient(new URI("ws://s1.ripple.com:443")) {
      case WebSocketClient.Messages.Connected(client)       => println("Connection has been established to: " + client.url.toASCIIString)
      case WebSocketClient.Messages.Disconnected(client, _) => println("The websocket to " + client.url.toASCIIString + " disconnected.")
      case WebSocketClient.Messages.TextMessage(client, message) => {
        println("RECV: " + message)
        //client send ("ECHO: " + message)
        client.disconnect
      }
    }
    client.connect
    client.send("{\"id\":1,\"command\":\"ping\"}", CharsetUtil.UTF_8)
  }
}